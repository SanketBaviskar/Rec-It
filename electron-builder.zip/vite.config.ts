import { defineConfig } from 'vite'
import path from "path"
import react from "@vitejs/plugin-react"
// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  base:'./',
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  build:{
    outDir:'dist-react'
  },
  server :{
    port :5123,
    strictPort: true
  }
})
