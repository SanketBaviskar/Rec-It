export default function SearchTab() {
    return (
        <div>
            Search Tab
        </div>
    )
}
