export default function EquipmentTab(){
    return(
        <div> euipment tab</div>
    )
}